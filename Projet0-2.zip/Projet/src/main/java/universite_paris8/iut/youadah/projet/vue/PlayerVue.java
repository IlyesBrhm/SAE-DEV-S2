package universite_paris8.iut.youadah.projet.vue;

public class PlayerVue {
}
