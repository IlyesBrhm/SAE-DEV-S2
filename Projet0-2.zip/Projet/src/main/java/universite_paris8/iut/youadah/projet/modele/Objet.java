package universite_paris8.iut.youadah.projet.modele;

public class Objet {
    public String nom;
    public int Rarete;



}
